<?php

$token = '11111111111:11111111111111111111111111111'; // telegram token  bot
$telegram_admin_id = '11111111111';  // your telegram id

// количество ip, далее блокирование
$countip = '2';
?>
